# QQ271 同盟活动 Android

这是“QQ271同盟活动”V5.2 本地版的 Android WebView 封装项目。

## 功能
- 内置 V5.2 HTML，离线打开
- 使用 Android WebView 保存本地 IndexedDB / localStorage 数据
- 支持 JSON 备份导入
- 支持从网页按钮导出 JSON 备份到 Android 系统文件选择器
- 自定义 App 图标
- 自定义启动页
- 返回键优先返回网页历史

## 自动生成 APK
推送到 `main` 后，GitHub Actions 会运行 `.github/workflows/build-apk.yml`。
构建成功后，在 Actions 对应运行页面的 Artifacts 中下载 `QQ271-APK`，解压即可得到 `app-debug.apk`。

> 当前是 debug APK，适合自己安装和测试。后续如需长期分发，可再添加 release 签名。
